import streamlit as st
import numpy as np
import joblib

st.set_page_config(page_title="Kidney Disease Prediction System", page_icon="🩺")
st.title("🩺 Kidney Disease Prediction System")
st.write("AI/ML-based prediction using patient medical information.")
st.warning("Academic/demo use only. This prediction is not a medical diagnosis.")

@st.cache_resource
def load_model():
    return joblib.load("model/kidney_model.pkl")

model=load_model()
st.subheader("Enter Patient Information")
c1,c2=st.columns(2)
with c1:
    age=st.number_input("Age",1,120,45,1)
    bp=st.number_input("Blood Pressure",0.0,250.0,80.0)
    urea=st.number_input("Blood Urea",0.0,300.0,40.0)
with c2:
    creat=st.number_input("Serum Creatinine",0.0,30.0,1.2)
    hb=st.number_input("Hemoglobin",0.0,25.0,13.0)

if st.button("Predict",type="primary",use_container_width=True):
    x=np.array([[age,bp,urea,creat,hb]])
    p=model.predict(x)[0]; prob=model.predict_proba(x)[0][1]
    if p:
        st.error(f"Result: Kidney Disease Detected | Model probability: {prob:.1%}")
    else:
        st.success(f"Result: No Kidney Disease | Model probability: {prob:.1%}")

st.divider()
st.caption("Kidney Disease Prediction System | BCA Part-III | Academic Year 2026–2027")
