# Kidney Disease Prediction System
Streamlit AI/ML academic project based on the supplied synopsis.

Inputs: Age, Blood Pressure, Blood Urea, Serum Creatinine, Hemoglobin.
Outputs: Kidney Disease Detected / No Kidney Disease.

Dataset specified by synopsis: Chronic Kidney Disease (CKD) Dataset (UCI Machine Learning Repository / Kaggle).

Run:
pip install -r requirements.txt
python train_model.py
streamlit run app.py

For final submission, replace data/kidney.csv with the actual CKD dataset using columns:
age,blood_pressure,blood_urea,serum_creatinine,hemoglobin,classification

Deploy app.py with Streamlit Community Cloud after uploading to GitHub.
