from pathlib import Path
import pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

BASE=Path(__file__).resolve().parent
df=pd.read_csv(BASE/"data/kidney.csv")
features=["age","blood_pressure","blood_urea","serum_creatinine","hemoglobin"]
X=df[features]; y=df["classification"]
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
model=Pipeline([("imputer",SimpleImputer(strategy="median")),("scaler",StandardScaler()),("classifier",LogisticRegression(max_iter=1000,random_state=42))])
model.fit(Xtr,ytr)
print("Accuracy:",round(accuracy_score(yte,model.predict(Xte)),4))
joblib.dump(model,BASE/"model/kidney_model.pkl")
print("Model saved.")
